import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { View } from 'react-native';
import { Theme } from '@/constants/Colors';

export default function RootLayout() {
    return (
        <View style={{ flex: 1, backgroundColor: Theme.colors.background }}>
            <StatusBar style="light" />
            <Stack
                screenOptions={{
                    headerStyle: {
                        backgroundColor: Theme.colors.background,
                    },
                    headerTintColor: Theme.colors.text,
                    headerTitleStyle: {
                        fontWeight: 'bold',
                    },
                    contentStyle: {
                        backgroundColor: Theme.colors.background,
                    },
                    headerShown: false,
                }}
            />
        </View>
    );
}
