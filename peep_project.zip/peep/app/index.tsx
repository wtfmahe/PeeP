import { View, Text, StyleSheet, FlatList, Alert, TouchableOpacity } from 'react-native';
import { Theme } from '@/constants/Colors';
// import PeepEye from '@/components/3d/PeepEye';
import FriendCard from '@/components/feature/FriendCard';
import { useEffect, useState } from 'react';
import { MockPeepService, MockPushNotification } from '@/services/MockPeepService';
import * as UsageStats from '@/modules/usage-stats';

const MOCK_FRIENDS = [
    { id: '1', name: 'Mahidhar', status: 'Idle 😴', peepsRemaining: 99 },
    { id: '2', name: 'Gemini', status: 'Coding 🤖', peepsRemaining: 99 },
    { id: '3', name: 'DeepMind', status: 'Thinking 🧠', peepsRemaining: 99 },
];

export default function HomeScreen() {
    const [friends, setFriends] = useState(MOCK_FRIENDS);

    useEffect(() => {
        // Listen for "Incoming Peeps" (Simulation of Push Notification)
        const subscription = MockPushNotification.addListener('incoming_peep', async (event: any) => {
            console.log('🔔 Notification:', event);

            // 1. Check Permission
            const hasPerm = await UsageStats.hasPermission();
            if (!hasPerm) {
                Alert.alert('Permission Needed', 'Allow usage access to let friends peep you.', [
                    { text: 'Open Settings', onPress: UsageStats.requestPermission },
                    { text: 'Cancel', style: 'cancel' }
                ]);
                return;
            }

            // 2. Get Real Activity
            const currentPkg = await UsageStats.getForegroundApp();
            const activity = currentPkg ? `Using ${currentPkg.split('.').pop()}` : 'Idle / Launcher';

            // 3. Show Result (In real app, send this to backend)
            Alert.alert('👀 You were Peeped!', `Friend saw: ${activity} \n(Pkg: ${currentPkg})`);
        });

        return () => {
            subscription.remove();
        };
    }, []);

    const handlePeep = async (id: string) => {
        // Check permission first
        const hasPerm = await UsageStats.hasPermission();
        if (!hasPerm) {
            Alert.alert('Permission Needed', 'Allow usage access to peep friends.', [
                { text: 'Open Settings', onPress: UsageStats.requestPermission },
                { text: 'Cancel', style: 'cancel' }
            ]);
            return;
        }

        // Optimistic Update - show "Peeping..."
        setFriends(prev => prev.map(f =>
            f.id === id ? { ...f, peepsRemaining: Math.max(0, f.peepsRemaining - 1), status: 'Peeping... 👀' } : f
        ));

        // Get REAL foreground app (simulating what friend's phone would return)
        const currentPkg = await UsageStats.getForegroundApp();
        const appName = currentPkg ? currentPkg.split('.').pop() : 'Idle';

        // Map package names to friendly names
        const friendlyName = getFriendlyAppName(currentPkg || '');

        // Update with REAL result
        setFriends(prev => prev.map(f =>
            f.id === id ? { ...f, status: friendlyName } : f
        ));
    };

    // Helper to convert package name to friendly display
    const getFriendlyAppName = (pkg: string): string => {
        const appMap: Record<string, string> = {
            'com.android.chrome': 'Browsing Chrome 🌐',
            'com.google.android.youtube': 'Watching YouTube 📺',
            'com.spotify.music': 'Listening to Spotify 🎵',
            'com.instagram.android': 'Scrolling Instagram 📸',
            'com.whatsapp': 'Chatting on WhatsApp 💬',
            'com.netflix.mediaclient': 'Watching Netflix 🎬',
            'com.anonymous.peep': 'Using Peep 👁️',
        };
        return appMap[pkg] || `Using ${pkg.split('.').pop() || 'Unknown'} 📱`;
    };

    const handleSimulateIncoming = () => {
        MockPeepService.simulateIncomingPeep();
    };

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.title}>Peep</Text>
                {/* <PeepEye style={styles.eye} /> */}
                <Text style={{ fontSize: 80 }}>👁️</Text>
            </View>

            <FlatList
                data={friends}
                keyExtractor={item => item.id}
                renderItem={({ item }) => (
                    <FriendCard
                        name={item.name}
                        status={item.status}
                        peepsRemaining={item.peepsRemaining}
                        onPeep={() => handlePeep(item.id)}
                    />
                )}
                contentContainerStyle={styles.list}
            />

            <TouchableOpacity style={styles.debugButton} onPress={handleSimulateIncoming}>
                <Text style={styles.debugText}>🔧 Simulate Incoming Peep</Text>
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Theme.colors.background,
        paddingTop: 60,
    },
    header: {
        height: 200,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 20,
    },
    title: {
        color: Theme.colors.text,
        fontSize: 48,
        fontWeight: 'bold',
        letterSpacing: 2,
        position: 'absolute',
        top: 0,
        zIndex: 1,
    },
    eye: {
        width: '100%',
        height: '100%',
    },
    list: {
        paddingHorizontal: 20,
        paddingBottom: 40,
    },
    debugButton: {
        position: 'absolute',
        bottom: 40,
        alignSelf: 'center',
        backgroundColor: '#333',
        padding: 12,
        borderRadius: 8,
        opacity: 0.8,
    },
    debugText: {
        color: 'white',
        fontSize: 12,
        fontWeight: 'bold',
    }
});
